public class Ex1 {
    public static void main(String[] args) {
        int soma = 0;

        for (int i = 1; i <= 50; i++) {
            soma += i;
        }

        System.out.println("A soma dos números de 1 a 50 é: " + soma);
    }
}