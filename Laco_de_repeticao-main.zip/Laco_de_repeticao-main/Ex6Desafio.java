import java.util.Scanner;

public class Ex6Desafio {
    public static void main(String [] args){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite 10 numeros:");
        int numeros = scanner.nextInt();


    }
}
