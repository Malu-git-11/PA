public class Ex10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     // Declaração de uma variável
     int a=40;
     int b=30;
     
     // processamento
     int soma = a+b;
     if (soma > 50) {
         System.out.println("a soma e maior que 50");
     } else { 
         System.out.println("a soma e menor que 50");
     }

    }
    
}
