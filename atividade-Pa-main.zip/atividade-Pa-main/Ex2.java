
public class Ex2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         // Declaração de uma variável
     int n=7;

    // Estrutura condicional if-else
    if (n > 0 ) {
    System.out.println("O numero e positivo.");
    } else {
        System.out.println("o numero e negativo");
}

    }
    
}
