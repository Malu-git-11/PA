public class Ex3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         // Declaração de uma variável
     int n=150;

    // Estrutura condicional if-else
    if (n > 100 ) {
    System.out.println("O numero 150 e maior que 100.");
    } else {
        System.out.println("o numero 150 e menor que 100");
}
    }
    
}
