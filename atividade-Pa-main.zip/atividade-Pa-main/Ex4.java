public class Ex4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         // Declaração de uma variável
     int n=5;

    // Estrutura condicional if-else
    if (n%2 == 0 ) {
    System.out.println("O numero 5 e par.");
    } else {
        System.out.println("o numero 5 e impar");
}
    }
    
}
