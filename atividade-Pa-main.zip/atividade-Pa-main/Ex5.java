public class Ex5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         // Declaração de uma variável
     int n=18;

    // Estrutura condicional if-else
    if (n <= 65 ) {
    System.out.println("a idade esta entre 18 e 65.");
    } else {
        System.out.println("a idade nao esta entre 18 e 65.");
}
    }
    
}
