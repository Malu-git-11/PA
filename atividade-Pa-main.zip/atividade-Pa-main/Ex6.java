public class Ex6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       // Declaração de uma variável
       int a=10;
       int b=20;
       
       //processamento
       int soma = a+b;
       
       //saida
       System.out.println("a soma e=" + soma);
            
    }
    
}
