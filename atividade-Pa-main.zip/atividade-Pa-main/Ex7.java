public class Ex7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         // Declaração de uma variável
       int a=5;
       int b=4;
       
       //processamento
       int multiplicaçao = a*b;
       
       //saida
       System.out.println("a multiplicaçao e=" + multiplicaçao);
    }
    
}
