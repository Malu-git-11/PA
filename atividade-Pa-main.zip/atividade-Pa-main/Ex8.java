public class Ex8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         // Declaração de uma variável
       int a=5;
        double b=2.5;
       
       //processamento
       double soma = a+b;
       
       //saida
       System.out.println("a soma e=" + soma);
    }
    
}
