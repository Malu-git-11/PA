public class Ex9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    // Declaração de uma variável
     String nome= "Joao";
     int i = 25;
     
     System.out.println(nome + "  tem  " + i);

    }
    
}
